import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import ProjectForm from '../components/ProjectForm';
import { navigate } from '@reach/router';

export default () => {

    const createProject = proj => {
        axios.post('http://localhost:8000/api/newproject/', proj)
        .then(res => {
            navigate('/')
        })
        .catch(err => {
            console.log(err)
        })
    }

    return(
        <div>
            <div>
                <ProjectForm onSubmitProp={createProject} initialName ="" initialDate ="" initialStatus = "0" />
            </div>
        </div>
    )
}