// import React, {useState, useEffect} from 'react';
// import DashList from '../components/DashList';
// import axios from 'axios';


// export default props => {

//     const {project, setProject} = props;

//     return (
//         <div>
//             <DashList project ={project} setProject={setProject}/>
//         </div>
//     )
// }