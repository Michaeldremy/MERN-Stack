import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DeleteButton from './DeleteButton';

export default props => {

    const [status, setStatus] = useState({
        status: props.status
    })

    const [progress, setProgress] = useState({
        progressStatus: 0
    })

    const [project, setProject] = useState({})

    // const moveToProgress =() => {
    //     setProject(prevState => {
    //         let project = Object.assign({}, prevState.project);
    //         project.status = 0;              
    //         return { project };
    //     })
    // }

    const showInProgess = () =>{
        setProgress({
            progressStatus: 1,
            status: project.status = 1
        })
        console.log(project.status)
    }

    const showCompleted = projectId => {
        setProgress({
            progressStatus: 2,
        })
    }

    useEffect(() => {
        axios.get('http://localhost:8000/api/project')
        .then(res => setProject(res.data))
    }, [])

    const removeFromDom = projectId => {
        setProject(project.filter(project => project._id !== projectId));
    }

    return(
    <div className="container">
        <div className="row text-center">
            <div className="col-12">
                <h1>Project Manager</h1>
            </div>
        </div>
        <div className="row pt-5">
            <div className="col-4">
                <h3 style={{color: "blue"}}>Backlog</h3>
            </div>
            <div className="col-4">
                <h3 style={{color: "orange"}}>In Progress</h3>
            </div>
            <div className="col-4">
                <h3 style={{color: "green"}}>Completed</h3>
            </div>
        </div>
        <div className="row pt-3">
            <div className="col-4">
            {`${progress.progressStatus}` == 0 ?
            props.project.filter(oneProj => oneProj.status === 0).map(filteredProject => (
                <div>
                    <h5>Project Name: {filteredProject.name}</h5>
                    <h5>Due: {filteredProject.date}</h5>
                    <button onClick={showInProgess}>Move to Completed</button>
                </div>
            ))
            :
            ""
            }
            </div>
            <div className="col-4">
            {`${progress.progressStatus}` == 1 ?
            props.project.filter(oneProj => oneProj.status === 1).map(filteredProject => (
                <div>
                    <h5>Project Name: {filteredProject.name}</h5>
                    <h5>Due: {filteredProject.date}</h5>
                    <button onClick={showCompleted}>Move to Completed</button>
                </div>
            ))
            :
            ""
            }
            </div>
            <div className="col-4">
            {`${progress.progressStatus}` == 2 ? 
            props.project.filter(oneProj => oneProj.status === 2 || 1 && oneProj.status != 0).map(filteredProject => (
                <div>
                    <h3>{filteredProject.name}</h3>
                    <DeleteButton projectId ={filteredProject._id} successCallback={() => removeFromDom(filteredProject._id)}/>
                </div>
                    ))
                    : 
                    ""
                    }
            </div>
        </div>
    </div>
    )
}