import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from '@reach/router';

export default props => {

    const {initialName, initialDate, onSubmitProp} = props;
    const [name, setName] = useState(initialName);
    const [date, setDate] = useState(initialDate);

    const onSubmitHandler = e => {
        e.preventDefault();
        onSubmitProp({name, date});
    }

    return(
        <div className="container">
            <form onSubmit ={onSubmitHandler}>
                <div className="row text-center pt-3">
                    <div className="col-12">
                        <h1>Project Manager</h1>
                        <Link to ="/">Dashboard</Link>
                    </div>
                    <div className="col-12 pt-2">
                        <h4>Plan a new Project</h4>
                    </div>
                    <div className="col-12 pt-2">
                        <label>Project:</label>
                        <input type="text"
                        name="name"
                        value={name}
                        onChange ={(e) => setName(e.target.value)}/>
                    </div>
                    <div className="col-12 pt-2">
                        <label>Due Date:</label>
                        <input type="date"
                        name="date"
                        value={date}
                        onChange ={(e) => setDate(e.target.value)}/>
                    </div>
                    <div className="col-12">
                        <button type="submit">Plan Project</button>
                    </div>
                </div>
            </form>
        </div>
    )
}